#!/usr/bin/env python3
"""Bounded PriceSmart HN Discovery totals and page-size probe."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import ssl
import tarfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ENDPOINT = "https://www.pricesmart.com/api/br_discovery/getProductsByKeyword"
CLUB = "6603"
EXCLUDED_CLUBS = ("6602", "6604")
BASE_ROWS = 12
PAGE_SIZE_CANDIDATES = (200, 100, 50)
MAX_POSTS = 31
MAX_RETRIES = 3
MAX_SECONDS = 10 * 60
MAX_DOCUMENTS = 500
TIMEOUT_SECONDS = 20
PACE_SECONDS = 0.12
ALIMENTOS_KEY = "G10D03"

try:
    import certifi
except ImportError:
    certifi = None

SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where() if certifi else None)


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def load_template(archive_path: Path) -> dict:
    with tarfile.open(archive_path, "r:gz") as archive:
        member = archive.extractfile("live/raw/requests/0001-6603-0000.json")
        if member is None:
            raise ValueError("template_missing")
        observed = json.loads(member.read())
    query = json.loads(observed["body_raw"])[0]
    fields = set(query.get("fl", "").split(","))
    required = {
        "price_HN_6603", "availability_HN_6603", "inventory_HN_6603",
        "saving_amount_HN_6603", "original_price_without_saving_HN_6603",
    }
    forbidden = {
        field for field in fields
        if any(f"_HN_{club}" in field for club in EXCLUDED_CLUBS)
    }
    if (
        observed.get("method") != "POST"
        or observed.get("url") != ENDPOINT
        or query.get("q") != ALIMENTOS_KEY
        or query.get("search_type") != "category"
        or query.get("view_id") != "HN"
        or query.get("start") != 0
        or query.get("rows") != 12
        or query.get("fq") != []
        or not required.issubset(fields)
        or forbidden
    ):
        raise ValueError("template_scope_invalid")
    return query


def load_roots(evidence_path: Path) -> list[dict]:
    evidence = json.loads(evidence_path.read_text())
    rows = evidence["taxonomy"]["categories"]
    roots = [row for row in rows if row["category_key"] != ALIMENTOS_KEY]
    expected = evidence["next_probe_preflight"]["remaining_root_keys"]
    if len(roots) != 25 or [row["category_key"] for row in roots] != expected:
        raise ValueError("root_scope_invalid")
    if any(row["parent"] is not None or row["ancestors"] != [] for row in roots):
        raise ValueError("non_root_in_scope")
    return roots


class Probe:
    def __init__(self, output: Path, template: dict, roots: list[dict]) -> None:
        self.output = output
        self.template = template
        self.roots = roots
        self.root_by_key = {row["category_key"]: row for row in roots}
        self.started_monotonic: float | None = None
        self.started_at: str | None = None
        self.attempts: list[dict] = []
        self.base: dict[str, dict] = {}
        self.page_size: dict | None = None
        self.retry_count = 0
        self.documents_returned = 0
        self.aborted_reason: str | None = None

    def elapsed(self) -> float:
        return 0.0 if self.started_monotonic is None else time.monotonic() - self.started_monotonic

    def state(self) -> dict:
        return {
            "schema_version": 1,
            "authorization": {
                "endpoint": ENDPOINT,
                "club": CLUB,
                "excluded_clubs": list(EXCLUDED_CLUBS),
                "pending_root_keys": [row["category_key"] for row in self.roots],
                "base_start": 0,
                "base_rows": BASE_ROWS,
                "page_size_candidates": list(PAGE_SIZE_CANDIDATES),
                "max_post_attempts": MAX_POSTS,
                "max_retries": MAX_RETRIES,
                "max_duration_seconds": MAX_SECONDS,
                "max_documents_returned": MAX_DOCUMENTS,
                "concurrency": 1,
                "full_crawl": False,
                "alimentos_recrawl": False,
                "turso": False,
            },
            "started_at_utc": self.started_at,
            "updated_at_utc": utcnow(),
            "elapsed_seconds": self.elapsed(),
            "post_attempts": len(self.attempts),
            "retries": self.retry_count,
            "documents_returned": self.documents_returned,
            "base_roots_complete": len(self.base),
            "page_size": self.page_size,
            "aborted_reason": self.aborted_reason,
            "attempts": self.attempts,
        }

    def persist(self) -> None:
        atomic_json(self.output / "ledger.json", self.state())

    def ensure_budget(self) -> None:
        if len(self.attempts) >= MAX_POSTS:
            raise RuntimeError("post_budget_exhausted")
        if self.retry_count > MAX_RETRIES:
            raise RuntimeError("retry_budget_exhausted")
        if self.started_monotonic is not None and self.elapsed() >= MAX_SECONDS:
            raise RuntimeError("duration_budget_exhausted")

    def request(self, key: str, rows: int, phase: str, retry_of: int | None = None) -> dict:
        self.ensure_budget()
        if key == ALIMENTOS_KEY or key not in self.root_by_key:
            raise RuntimeError("category_out_of_scope")
        if phase == "base" and rows != BASE_ROWS:
            raise RuntimeError("base_rows_out_of_scope")
        if phase == "page_size" and rows not in PAGE_SIZE_CANDIDATES:
            raise RuntimeError("page_size_out_of_scope")
        if retry_of is not None:
            if self.retry_count >= MAX_RETRIES:
                raise RuntimeError("retry_budget_exhausted")
            self.retry_count += 1
        if self.started_monotonic is None:
            self.started_monotonic = time.monotonic()
            self.started_at = utcnow()

        root = self.root_by_key[key]
        query = dict(self.template)
        query.update({
            "url": f"https://www.pricesmart.com/es-hn/categoria/{root['slug']}/{key}",
            "start": 0,
            "q": key,
            "rows": rows,
            "request_id": int(time.time() * 1000),
        })
        body = json.dumps([query], ensure_ascii=False, separators=(",", ":")).encode()
        attempt_number = len(self.attempts) + 1
        tag = f"{attempt_number:02d}-{phase}-{key}-rows-{rows}"
        request_rel = f"raw/requests/{tag}.json"
        response_rel = f"raw/responses/{tag}.json"
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "Referer": query["url"],
        }
        request_record = {
            "attempt_number": attempt_number,
            "retry_of": retry_of,
            "phase": phase,
            "category_key": key,
            "category_name": root["name"],
            "start": 0,
            "rows": rows,
            "method": "POST",
            "url": ENDPOINT,
            "headers": headers,
            "cookie_header_present": False,
            "body_raw": body.decode(),
            "body_sha256": digest(body),
            "observed_at_utc": utcnow(),
        }
        atomic_json(self.output / request_rel, request_record)
        attempt = {
            "attempt_number": attempt_number,
            "retry_of": retry_of,
            "phase": phase,
            "category_key": key,
            "start": 0,
            "rows": rows,
            "request_file": request_rel,
            "request_sha256": digest((self.output / request_rel).read_bytes()),
            "started_at_utc": utcnow(),
            "valid": False,
        }
        self.attempts.append(attempt)
        self.persist()

        request = urllib.request.Request(ENDPOINT, data=body, method="POST", headers=headers)
        began = time.monotonic()
        status = None
        response_body = b""
        response_headers: dict[str, str] = {}
        error = None
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=SSL_CONTEXT) as response:
                status = response.status
                response_body = response.read()
                response_headers = {"Content-Type": response.headers.get("Content-Type", "")}
        except urllib.error.HTTPError as exc:
            status = exc.code
            response_body = exc.read()
            response_headers = {"Content-Type": exc.headers.get("Content-Type", "")}
            error = f"http_error:{exc.code}"
        except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as exc:
            error = f"transport_error:{type(exc).__name__}:{exc}"

        response_record = {
            "status": status,
            "headers": response_headers,
            "body_raw": response_body.decode("utf-8", errors="replace"),
            "body_sha256": digest(response_body),
            "body_bytes": len(response_body),
            "elapsed_seconds": time.monotonic() - began,
            "finished_at_utc": utcnow(),
            "error": error,
        }
        atomic_json(self.output / response_rel, response_record)
        attempt.update({
            "response_file": response_rel,
            "response_sha256": digest((self.output / response_rel).read_bytes()),
            "http_status": status,
            "response_body_sha256": response_record["body_sha256"],
            "response_bytes": len(response_body),
            "elapsed_seconds": response_record["elapsed_seconds"],
            "error": error,
        })

        lower = response_record["body_raw"].lower()
        if status in (403, 429) or "captcha" in lower or "cf-chl-" in lower:
            self.aborted_reason = f"anti_bot_or_rate_limit:{status}"
            self.persist()
            raise RuntimeError(self.aborted_reason)
        if status in (401,) or "authentication required" in lower or "unauthorized" in lower:
            self.aborted_reason = f"authentication_required:{status}"
            self.persist()
            raise RuntimeError(self.aborted_reason)

        if phase == "page_size" and status in (400, 413, 422) and error is not None:
            attempt["clean_size_rejection"] = True
            self.persist()
            time.sleep(PACE_SECONDS)
            return {"outcome": "clean_size_rejection"}

        if error is not None:
            attempt["retryable"] = status is None or (isinstance(status, int) and 500 <= status < 600)
            self.persist()
            time.sleep(PACE_SECONDS)
            return {"outcome": "retryable" if attempt["retryable"] else "unexpected"}

        try:
            payload = json.loads(response_body)
            response = payload["response"]
            docs = response["docs"]
            total = response["numFound"]
            start = response["start"]
            facets = payload["facet_counts"]["facet_fields"]["category"]
            category_map = payload["category_map"]
            expected_count = min(rows, total)
            if (
                status != 200
                or start != 0
                or not isinstance(total, int)
                or total < 0
                or not isinstance(docs, list)
                or len(docs) != expected_count
                or len({doc["pid"] for doc in docs}) != len(docs)
                or not isinstance(facets, list)
                or not isinstance(category_map, dict)
            ):
                raise ValueError("response_window_or_facet_invalid")
            if phase == "page_size" and self.base[key]["num_found"] != total:
                raise ValueError("num_found_changed_during_probe")
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            self.aborted_reason = f"unexpected_contract:{type(exc).__name__}:{exc}"
            attempt["error"] = self.aborted_reason
            self.persist()
            raise RuntimeError(self.aborted_reason)

        self.documents_returned += len(docs)
        if self.documents_returned > MAX_DOCUMENTS:
            self.aborted_reason = "document_budget_exceeded"
            self.persist()
            raise RuntimeError(self.aborted_reason)
        attempt.update({
            "valid": True,
            "num_found": total,
            "returned_documents": len(docs),
            "facet_nodes": len(facets),
            "category_map_entries": len(category_map),
        })
        self.persist()
        time.sleep(PACE_SECONDS)
        return {
            "outcome": "valid",
            "num_found": total,
            "returned_documents": len(docs),
            "facet_nodes": len(facets),
            "category_map_entries": len(category_map),
            "request_attempt": attempt_number,
        }

    def request_with_retries(self, key: str, rows: int, phase: str) -> dict:
        first_attempt = None
        while True:
            result = self.request(key, rows, phase, retry_of=first_attempt)
            if result["outcome"] in {"valid", "clean_size_rejection"}:
                return result
            if result["outcome"] != "retryable":
                self.aborted_reason = "unexpected_http_contract"
                self.persist()
                raise RuntimeError(self.aborted_reason)
            if self.retry_count >= MAX_RETRIES:
                self.aborted_reason = "retry_budget_exhausted"
                self.persist()
                raise RuntimeError(self.aborted_reason)
            if first_attempt is None:
                first_attempt = self.attempts[-1]["attempt_number"]

    def run(self) -> None:
        self.output.mkdir(parents=True, exist_ok=False)
        self.persist()
        for root in self.roots:
            key = root["category_key"]
            result = self.request_with_retries(key, BASE_ROWS, "base")
            self.base[key] = result
            self.persist()

        largest_key = max(self.base, key=lambda key: (self.base[key]["num_found"], key))
        size_attempts = []
        for rows in PAGE_SIZE_CANDIDATES:
            result = self.request_with_retries(largest_key, rows, "page_size")
            size_attempts.append({"rows": rows, **result})
            if result["outcome"] == "valid":
                self.page_size = {
                    "category_key": largest_key,
                    "category_num_found": self.base[largest_key]["num_found"],
                    "requested_rows": rows,
                    "returned_documents": result["returned_documents"],
                    "accepted": True,
                    "attempts": size_attempts,
                }
                break
        if self.page_size is None:
            self.aborted_reason = "no_page_size_candidate_accepted"
            self.persist()
            raise RuntimeError(self.aborted_reason)

        result = {
            "complete": True,
            "started_at_utc": self.started_at,
            "finished_at_utc": utcnow(),
            "elapsed_seconds": self.elapsed(),
            "post_attempts": len(self.attempts),
            "retries": self.retry_count,
            "remaining_post_budget": MAX_POSTS - len(self.attempts),
            "documents_returned": self.documents_returned,
            "root_count": len(self.base),
            "base": self.base,
            "page_size": self.page_size,
        }
        atomic_json(self.output / "result.json", result)
        self.persist()
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--template-archive", type=Path, required=True)
    parser.add_argument("--taxonomy-evidence", type=Path, required=True)
    args = parser.parse_args()
    probe = Probe(args.output, load_template(args.template_archive), load_roots(args.taxonomy_evidence))
    probe.run()


if __name__ == "__main__":
    main()
