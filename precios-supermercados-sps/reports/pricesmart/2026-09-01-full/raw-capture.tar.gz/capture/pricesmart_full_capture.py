#!/usr/bin/env python3
"""Bounded one-shot PriceSmart HN full capture for the authorized clubs."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import socket
import ssl
import tarfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ENDPOINT = "https://www.pricesmart.com/api/br_discovery/getProductsByKeyword"
CLUBS = ("6603", "6602")
ROWS = 12
MAX_POSTS = 208
MAX_SECONDS = 30 * 60
MAX_RETRIES = 20
TIMEOUT_SECONDS = 20
PACE_SECONDS = 0.10
EXPECTED_TOTAL = 1124

try:
    import certifi
except ImportError:
    certifi = None

SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where() if certifi else None)


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def load_templates(probe_archive: Path) -> dict[str, dict]:
    templates = {}
    with tarfile.open(probe_archive, "r:gz") as archive:
        for club in CLUBS:
            member = archive.extractfile(f"raw/requests/{club}.json")
            if member is None:
                raise ValueError(f"template_missing:{club}")
            observed = json.loads(member.read())
            body = json.loads(observed["body_raw"])
            if len(body) != 1:
                raise ValueError(f"template_batch_invalid:{club}")
            query = body[0]
            required = {
                f"price_HN_{club}", f"availability_HN_{club}",
                f"inventory_HN_{club}", f"saving_amount_HN_{club}",
                f"original_price_without_saving_HN_{club}",
            }
            if (
                observed["method"] != "POST"
                or observed["url"] != ENDPOINT
                or query.get("q") != "G10D03"
                or query.get("view_id") != "HN"
                or query.get("rows") != ROWS
                or not required.issubset(set(query.get("fl", "").split(",")))
            ):
                raise ValueError(f"template_scope_invalid:{club}")
            templates[club] = {
                "query": query,
                "referer": observed["headers"]["Referer"],
            }
    return templates


class Capture:
    def __init__(self, output: Path, templates: dict[str, dict]) -> None:
        self.output = output
        self.templates = templates
        self.started_monotonic: float | None = None
        self.started_at: str | None = None
        self.attempts: list[dict] = []
        self.success: dict[tuple[str, int], dict] = {}
        self.expected_total: dict[str, int] = {}
        self.aborted_reason: str | None = None

    def elapsed(self) -> float:
        return 0.0 if self.started_monotonic is None else time.monotonic() - self.started_monotonic

    def state(self) -> dict:
        return {
            "schema_version": 1,
            "authorization": {
                "clubs": list(CLUBS),
                "excluded_club": "6604",
                "endpoint": ENDPOINT,
                "max_post_attempts": MAX_POSTS,
                "max_retries": MAX_RETRIES,
                "concurrency": 1,
                "max_duration_seconds": MAX_SECONDS,
                "login": False,
                "cart": False,
                "checkout": False,
                "turso": False,
                "recurrence": False,
            },
            "started_at_utc": self.started_at,
            "updated_at_utc": utcnow(),
            "elapsed_seconds": self.elapsed(),
            "post_attempts": len(self.attempts),
            "successful_pages": len(self.success),
            "expected_total_by_club": self.expected_total,
            "aborted_reason": self.aborted_reason,
            "attempts": self.attempts,
        }

    def persist_state(self) -> None:
        atomic_json(self.output / "ledger.json", self.state())

    def ensure_budget(self) -> None:
        if len(self.attempts) >= MAX_POSTS:
            raise RuntimeError("post_budget_exhausted")
        if self.started_monotonic is not None and self.elapsed() >= MAX_SECONDS:
            raise RuntimeError("duration_budget_exhausted")

    def request(self, club: str, start: int, phase: str) -> bool:
        self.ensure_budget()
        if self.started_monotonic is None:
            self.started_monotonic = time.monotonic()
            self.started_at = utcnow()
        template = self.templates[club]
        query = dict(template["query"])
        query["start"] = start
        query["rows"] = ROWS
        query["request_id"] = int(time.time() * 1000)
        body = json.dumps([query], ensure_ascii=False, separators=(",", ":")).encode()
        attempt_number = len(self.attempts) + 1
        tag = f"{attempt_number:04d}-{club}-{start:04d}"
        request_rel = f"raw/requests/{tag}.json"
        response_rel = f"raw/responses/{tag}.json"
        request_record = {
            "method": "POST",
            "url": ENDPOINT,
            "headers": {
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json",
                "Referer": template["referer"],
            },
            "body_raw": body.decode(),
            "body_sha256": digest(body),
            "cookie_header_present": False,
            "club": club,
            "start": start,
            "rows": ROWS,
            "phase": phase,
            "attempt_number": attempt_number,
            "observed_at_utc": utcnow(),
        }
        atomic_json(self.output / request_rel, request_record)
        record = {
            "attempt_number": attempt_number,
            "club": club,
            "start": start,
            "rows": ROWS,
            "phase": phase,
            "request_file": request_rel,
            "request_sha256": digest((self.output / request_rel).read_bytes()),
            "started_at_utc": utcnow(),
        }
        self.attempts.append(record)
        self.persist_state()

        request = urllib.request.Request(
            ENDPOINT,
            data=body,
            method="POST",
            headers=request_record["headers"],
        )
        began = time.monotonic()
        status = None
        response_body = b""
        headers: dict[str, str] = {}
        error: str | None = None
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=SSL_CONTEXT) as response:
                status = response.status
                response_body = response.read()
                headers = {"Content-Type": response.headers.get("Content-Type", "")}
        except urllib.error.HTTPError as exc:
            status = exc.code
            response_body = exc.read()
            headers = {"Content-Type": exc.headers.get("Content-Type", "")}
            error = f"http_error:{exc.code}"
        except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as exc:
            error = f"transport_error:{type(exc).__name__}:{exc}"

        response_record = {
            "status": status,
            "headers": headers,
            "body_raw": response_body.decode("utf-8", errors="replace"),
            "body_sha256": digest(response_body),
            "body_bytes": len(response_body),
            "elapsed_seconds": time.monotonic() - began,
            "finished_at_utc": utcnow(),
            "error": error,
        }
        atomic_json(self.output / response_rel, response_record)
        record.update({
            "response_file": response_rel,
            "response_sha256": digest((self.output / response_rel).read_bytes()),
            "http_status": status,
            "response_body_sha256": response_record["body_sha256"],
            "response_bytes": len(response_body),
            "elapsed_seconds": response_record["elapsed_seconds"],
            "error": error,
            "valid": False,
        })

        lower = response_record["body_raw"].lower()
        if status in (403, 429) or "captcha" in lower or "cf-chl-" in lower:
            self.aborted_reason = f"anti_bot_or_rate_limit:{status}"
            self.persist_state()
            raise RuntimeError(self.aborted_reason)

        if error is None:
            try:
                payload = json.loads(response_body)
                response = payload["response"]
                docs = response["docs"]
                total = response["numFound"]
                expected_count = min(ROWS, max(0, total - start))
                if (
                    status != 200
                    or response["start"] != start
                    or not isinstance(total, int)
                    or total <= 0
                    or len(docs) != expected_count
                    or len({doc["pid"] for doc in docs}) != len(docs)
                ):
                    raise ValueError("response_window_invalid")
                prior_total = self.expected_total.get(club)
                if prior_total is not None and prior_total != total:
                    raise ValueError("catalog_total_changed_during_capture")
                self.expected_total[club] = total
                record["valid"] = True
                record["catalog_total"] = total
                record["returned_products"] = len(docs)
                record["response_file"] = response_rel
                self.success[(club, start)] = record.copy()
            except (ValueError, KeyError, TypeError) as exc:
                record["error"] = f"validation_error:{type(exc).__name__}:{exc}"
        self.persist_state()
        time.sleep(PACE_SECONDS)
        return bool(record["valid"])

    def run(self) -> None:
        self.output.mkdir(parents=True, exist_ok=False)
        self.persist_state()
        planned = {
            club: list(range(0, math.ceil(EXPECTED_TOTAL / ROWS) * ROWS, ROWS))
            for club in CLUBS
        }
        base_pages = sum(len(offsets) for offsets in planned.values())
        if base_pages > MAX_POSTS - MAX_RETRIES:
            raise RuntimeError(f"base_plan_exceeds_reserved_budget:{base_pages}")

        for club in CLUBS:
            for start in planned[club]:
                self.request(club, start, "base")
                observed_total = self.expected_total.get(club)
                if observed_total is not None and observed_total != EXPECTED_TOTAL:
                    self.aborted_reason = f"catalog_total_changed_from_preflight:{club}:{observed_total}"
                    self.persist_state()
                    raise RuntimeError(self.aborted_reason)

        residual = [(club, start) for club in CLUBS for start in planned[club] if (club, start) not in self.success]
        retry_count = 0
        while residual and retry_count < MAX_RETRIES and len(self.attempts) < MAX_POSTS:
            club, start = residual.pop(0)
            retry_count += 1
            self.request(club, start, "residual_retry")
            if (club, start) not in self.success:
                residual.append((club, start))

        if residual:
            self.aborted_reason = "residual_pages_incomplete"
        self.persist_state()
        atomic_json(self.output / "result.json", {
            "complete": not residual and self.aborted_reason is None,
            "clubs": list(CLUBS),
            "excluded_club": "6604",
            "base_pages": base_pages,
            "successful_pages": len(self.success),
            "post_attempts": len(self.attempts),
            "retries": sum(row["phase"] == "residual_retry" for row in self.attempts),
            "remaining_budget": MAX_POSTS - len(self.attempts),
            "elapsed_seconds": self.elapsed(),
            "expected_total_by_club": self.expected_total,
            "residual_pages": [{"club": club, "start": start} for club, start in residual],
            "aborted_reason": self.aborted_reason,
            "finished_at_utc": utcnow(),
        })
        if residual or self.aborted_reason:
            raise RuntimeError(self.aborted_reason or "capture_incomplete")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--probe-archive", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    templates = load_templates(args.probe_archive)
    if args.dry_run:
        print(json.dumps({
            "endpoint": ENDPOINT,
            "clubs": list(CLUBS),
            "excluded_club": "6604",
            "rows": ROWS,
            "expected_pages_per_club": math.ceil(EXPECTED_TOTAL / ROWS),
            "expected_base_posts": 2 * math.ceil(EXPECTED_TOTAL / ROWS),
            "max_posts": MAX_POSTS,
            "max_retries": MAX_RETRIES,
            "concurrency": 1,
            "max_seconds": MAX_SECONDS,
        }, indent=2))
        return
    Capture(args.output, templates).run()


if __name__ == "__main__":
    main()
