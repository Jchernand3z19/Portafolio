import hashlib,json,pathlib,sys,time,datetime,urllib.parse
import requests
ROOT=pathlib.Path(__file__).resolve().parent
ledger=ROOT/'ledger.json'
if ledger.exists():
    raise SystemExit('Refusing to reset an existing probe ledger')
state={'authorization_start_utc':'2026-08-31T00:17:55Z','authorization_end_utc':'2026-09-01T00:17:55Z','limit_requests':20,'limit_seconds':600,'concurrency':1,'max_transient_retries':2,'requests':[],'stopped':False}
session=requests.Session()
session.headers.update({'User-Agent':'Mozilla/5.0 (compatible; PublicCatalogResearch/1.0)','Accept':'text/html,application/json;q=0.9,*/*;q=0.1'})
start=None
previous=0.0
retries=0
print(json.dumps({'ready':True}),flush=True)
for line in sys.stdin:
    try:
        command=json.loads(line)
        if command.get('quit'): break
        url=command['url']; purpose=command['purpose']
        parsed=urllib.parse.urlsplit(url)
        if parsed.scheme!='https' or parsed.hostname not in {'www.walmart.com.hn','walmarthn.vtexassets.com'} or parsed.username or parsed.password:
            raise ValueError('URL outside authorized public hosts')
        if state['stopped']: raise ValueError('Probe stopped; no further requests')
        matches=[r for r in state['requests'] if r['url']==url]
        if matches:
            if len(matches)>1 or retries>=2 or not (matches[-1].get('status',0)>=500 or matches[-1].get('error')=='Timeout'):
                raise ValueError('Duplicate resource not eligible for retry')
            retries+=1
        if len(state['requests'])>=20: raise ValueError('Request budget exhausted')
        if start is None: start=time.monotonic()
        if time.monotonic()-start>=600: raise ValueError('Probe duration exhausted')
        time.sleep(max(0,1-(time.monotonic()-previous)))
        now=datetime.datetime.now(datetime.timezone.utc)
        if now>=datetime.datetime.fromisoformat(state['authorization_end_utc'].replace('Z','+00:00')): raise ValueError('Authorization expired')
        index=len(state['requests'])+1
        record={'index':index,'method':'GET','url':url,'purpose':purpose,'started_utc':now.isoformat(),'retry':bool(matches)}
        state['requests'].append(record);ledger.write_text(json.dumps(state,indent=2))
        previous=time.monotonic()
        try:
            response=session.get(url,timeout=min(20,max(1,600-(time.monotonic()-start))),allow_redirects=False)
            raw=response.content
            filename=f'{index:02d}.raw'
            (ROOT/filename).write_bytes(raw)
            record.update(status=response.status_code,content_type=response.headers.get('Content-Type'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),raw=filename,elapsed_seconds=round(time.monotonic()-previous,3))
            if response.is_redirect: record['location']=response.headers.get('Location')
            if response.status_code in {401,403,429}: state['stopped']=True;state['stop_reason']=f'HTTP {response.status_code}'
            beginning=raw[:100000].lower()
            if any(token in beginning for token in [b'<title>access denied',b'<title>just a moment',b'<title>robot or human',b'<title>captcha']): state['stopped']=True;state['stop_reason']='Anti-bot challenge'
        except requests.RequestException as exc:
            record['error']='Timeout' if isinstance(exc,requests.Timeout) else type(exc).__name__
            record['elapsed_seconds']=round(time.monotonic()-previous,3)
            if record['error']!='Timeout': state['stopped']=True;state['stop_reason']=record['error']
        state['elapsed_seconds']=round(time.monotonic()-start,3)
        ledger.write_text(json.dumps(state,indent=2))
        print(json.dumps({'request':record,'stopped':state['stopped']}),flush=True)
    except Exception as exc:
        print(json.dumps({'refused':str(exc)}),flush=True)
