#!/usr/bin/env python3
"""One-request recovery capture for the authorized PriceSmart root probe."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import ssl
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ENDPOINT = "https://www.pricesmart.com/api/ct/getFacetCategories"
BODY = [{"onlyParent": True, "limit": 200, "offset": 0}]
MAX_SECONDS = 5 * 60
TIMEOUT_SECONDS = 20

try:
    import certifi
except ImportError:
    certifi = None

SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where() if certifi else None)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)

    started = time.monotonic()
    started_at = now()
    body = json.dumps(BODY, ensure_ascii=False, separators=(",", ":")).encode()
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json",
        "Cookie": "vsf-locale=es-HN; vsf-currency=HNL; vsf-country=HN; vsf-store=HN",
        "Referer": "https://www.pricesmart.com/es-hn",
    }
    request_record = {
        "global_authorized_attempt_number": 2,
        "phase": "recovery_retry_after_ephemeral_worktree_loss",
        "method": "POST",
        "url": ENDPOINT,
        "operation": "getFacetCategories",
        "headers": headers,
        "body_raw": body.decode(),
        "body_sha256": digest(body),
        "observed_at_utc": now(),
    }
    request_path = args.output / "raw/requests/02-root-offset-0000-recovery.json"
    atomic_json(request_path, request_record)

    request = urllib.request.Request(ENDPOINT, data=body, method="POST", headers=headers)
    began = time.monotonic()
    status = None
    response_body = b""
    response_headers: dict[str, str] = {}
    error = None
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=SSL_CONTEXT) as response:
            status = response.status
            response_body = response.read()
            response_headers = {"Content-Type": response.headers.get("Content-Type", "")}
    except urllib.error.HTTPError as exc:
        status = exc.code
        response_body = exc.read()
        response_headers = {"Content-Type": exc.headers.get("Content-Type", "")}
        error = f"http_error:{exc.code}"
    except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as exc:
        error = f"transport_error:{type(exc).__name__}:{exc}"

    response_record = {
        "status": status,
        "headers": response_headers,
        "body_raw": response_body.decode("utf-8", errors="replace"),
        "body_sha256": digest(response_body),
        "body_bytes": len(response_body),
        "elapsed_seconds": time.monotonic() - began,
        "finished_at_utc": now(),
        "error": error,
    }
    response_path = args.output / "raw/responses/02-root-offset-0000-recovery.json"
    atomic_json(response_path, response_record)

    lower = response_record["body_raw"].lower()
    if status in (403, 429) or "captcha" in lower or "cf-chl-" in lower:
        raise SystemExit(f"stop_control:{status}")
    if error is not None:
        raise SystemExit(error)
    try:
        decoded = json.loads(response_body)
        categories = decoded["data"]["categories"]["results"]
        valid = (
            status == 200
            and not decoded.get("errors")
            and isinstance(categories, list)
            and len(categories) < 200
            and all(
                isinstance(row.get("id"), str)
                and isinstance(row.get("key"), str)
                and isinstance(row.get("name"), str)
                and isinstance(row.get("slug"), str)
                and row.get("parent") is None
                and row.get("ancestors") == []
                for row in categories
            )
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        valid = False
        categories = []
    if not valid:
        raise SystemExit("unexpected_contract")
    if time.monotonic() - started > MAX_SECONDS:
        raise SystemExit("duration_budget_exceeded")

    result = {
        "complete": True,
        "started_at_utc": started_at,
        "finished_at_utc": now(),
        "elapsed_seconds": time.monotonic() - started,
        "this_run_post_attempts": 1,
        "global_authorized_post_attempts": 2,
        "global_authorized_retries": 1,
        "remaining_post_budget": 2,
        "categories": len(categories),
        "offsets": [0],
        "offset_200_requested": False,
        "response_body_sha256": response_record["body_sha256"],
    }
    atomic_json(args.output / "result.json", result)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
