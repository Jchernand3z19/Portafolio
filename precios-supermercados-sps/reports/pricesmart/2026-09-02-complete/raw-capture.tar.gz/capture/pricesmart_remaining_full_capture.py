#!/usr/bin/env python3
"""Authorized bounded capture of the remaining PriceSmart HN root catalogs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import ssl
import tarfile
import time
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ENDPOINT = "https://www.pricesmart.com/api/br_discovery/getProductsByKeyword"
CLUBS = ("6603", "6602")
EXCLUDED_CLUB = "6604"
ROWS = 200
MAX_POSTS = 55
MAX_RETRIES = 5
MAX_SECONDS = 10 * 60
MAX_NEW_DOCUMENTS = 3306
TIMEOUT_SECONDS = 20
PACE_SECONDS = 0.12

try:
    import certifi
except ImportError:
    certifi = None

SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where() if certifi else None)


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def load_templates(alimentos_archive: Path) -> dict[str, dict]:
    templates: dict[str, dict] = {}
    with tarfile.open(alimentos_archive, "r:gz") as archive:
        for member in archive.getmembers():
            if not member.isfile() or not member.name.startswith("live/raw/requests/"):
                continue
            name = Path(member.name).name
            for club in CLUBS:
                if club in templates or f"-{club}-" not in name:
                    continue
                observed = json.loads(archive.extractfile(member).read())
                query = json.loads(observed["body_raw"])[0]
                fields = set(query.get("fl", "").split(","))
                required = {
                    f"price_HN_{club}", f"availability_HN_{club}",
                    f"inventory_HN_{club}", f"saving_amount_HN_{club}",
                    f"original_price_without_saving_HN_{club}",
                }
                forbidden = {
                    field for field in fields
                    if any(f"_HN_{other}" in field for other in CLUBS + (EXCLUDED_CLUB,) if other != club)
                }
                if (
                    observed.get("method") != "POST"
                    or observed.get("url") != ENDPOINT
                    or query.get("q") != "G10D03"
                    or query.get("view_id") != "HN"
                    or query.get("search_type") != "category"
                    or query.get("fq") != []
                    or not required.issubset(fields)
                    or forbidden
                ):
                    raise ValueError(f"template_scope_invalid:{club}")
                templates[club] = query
    if set(templates) != set(CLUBS):
        raise ValueError("club_template_missing")
    return templates


class Capture:
    def __init__(self, output: Path, templates: dict[str, dict], evidence: dict,
                 taxonomy: dict) -> None:
        self.output = output
        self.templates = templates
        self.evidence = evidence
        self.root_by_key = {row["category_key"]: row for row in taxonomy["taxonomy"]["categories"]}
        self.expected = {
            row["category_key"]: row for row in evidence["catalog"]["root_plan"]
            if row["category_key"] != "G10D03" and row["num_found"] > 0
        }
        self.started_monotonic: float | None = None
        self.started_at: str | None = None
        self.attempts: list[dict] = []
        self.retry_count = 0
        self.new_documents = 0
        self.aborted_reason: str | None = None
        self.docs: dict[str, dict[str, list[dict]]] = {
            "6603": {},
            "6602": {},
        }
        self.windows: dict[str, dict[str, list[dict]]] = {
            "6603": defaultdict(list),
            "6602": defaultdict(list),
        }
        self.plan = self._build_plan()

    def _build_plan(self) -> list[dict]:
        plan: list[dict] = []
        for club in CLUBS:
            for row in self.evidence["catalog"]["root_plan"]:
                if row["category_key"] == "G10D03" or row["num_found"] == 0:
                    continue
                for start in range(0, row["num_found"], ROWS):
                    plan.append({"club": club, "category_key": row["category_key"], "start": start})
        if len(plan) != 50:
            raise ValueError(f"base_plan_not_50:{len(plan)}")
        if sum(item["club"] == "6603" for item in plan) != 25:
            raise ValueError("sps_plan_not_25")
        if sum(item["club"] == "6602" for item in plan) != 25:
            raise ValueError("florencia_plan_not_25")
        return plan

    def elapsed(self) -> float:
        return 0.0 if self.started_monotonic is None else time.monotonic() - self.started_monotonic

    def state(self) -> dict:
        return {
            "schema_version": 1,
            "authorization": {
                "endpoint": ENDPOINT,
                "clubs": list(CLUBS),
                "excluded_club": EXCLUDED_CLUB,
                "rows": ROWS,
                "base_post_requests": 50,
                "max_post_attempts": MAX_POSTS,
                "max_retries": MAX_RETRIES,
                "max_duration_seconds": MAX_SECONDS,
                "max_new_documents": MAX_NEW_DOCUMENTS,
                "concurrency": 1,
                "alimentos_recrawl": False,
                "partial_probe_windows_reused": False,
                "prior_fail_closed_post_attempts": 1,
                "turso": False,
            },
            "started_at_utc": self.started_at,
            "updated_at_utc": utcnow(),
            "elapsed_seconds": self.elapsed(),
            "post_attempts": len(self.attempts),
            "retries": self.retry_count,
            "new_documents": self.new_documents,
            "successful_pages": sum(row.get("valid", False) for row in self.attempts),
            "aborted_reason": self.aborted_reason,
            "attempts": self.attempts,
        }

    def persist(self) -> None:
        atomic_json(self.output / "ledger.json", self.state())

    def ensure_budget(self) -> None:
        if len(self.attempts) >= MAX_POSTS:
            raise RuntimeError("post_budget_exhausted")
        if self.retry_count > MAX_RETRIES:
            raise RuntimeError("retry_budget_exhausted")
        if self.started_monotonic is not None and self.elapsed() >= MAX_SECONDS:
            raise RuntimeError("duration_budget_exhausted")

    def request(self, club: str, key: str, start: int, retry_of: int | None = None) -> dict:
        self.ensure_budget()
        if club not in CLUBS or key not in self.expected or key == "G10D03":
            raise RuntimeError("request_scope_invalid")
        expected_starts = list(range(0, self.expected[key]["num_found"], ROWS))
        if start not in expected_starts:
            raise RuntimeError("offset_out_of_scope")
        if retry_of is not None:
            if self.retry_count >= MAX_RETRIES:
                raise RuntimeError("retry_budget_exhausted")
            self.retry_count += 1
        if self.started_monotonic is None:
            self.started_monotonic = time.monotonic()
            self.started_at = utcnow()

        root = self.root_by_key[key]
        query = dict(self.templates[club])
        query.update({
            "url": f"https://www.pricesmart.com/es-hn/categoria/{root['slug']}/{key}",
            "start": start,
            "q": key,
            "rows": ROWS,
            "request_id": int(time.time() * 1000),
        })
        body = json.dumps([query], ensure_ascii=False, separators=(",", ":")).encode()
        attempt_number = len(self.attempts) + 1
        tag = f"{attempt_number:02d}-{club}-{key}-start-{start:04d}"
        request_rel = f"raw/requests/{tag}.json"
        response_rel = f"raw/responses/{tag}.json"
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "Referer": query["url"],
        }
        request_record = {
            "attempt_number": attempt_number,
            "retry_of": retry_of,
            "club": club,
            "category_key": key,
            "start": start,
            "rows": ROWS,
            "method": "POST",
            "url": ENDPOINT,
            "headers": headers,
            "cookie_header_present": False,
            "body_raw": body.decode(),
            "body_sha256": digest(body),
            "observed_at_utc": utcnow(),
        }
        atomic_json(self.output / request_rel, request_record)
        attempt = {
            "attempt_number": attempt_number,
            "retry_of": retry_of,
            "club": club,
            "category_key": key,
            "start": start,
            "rows": ROWS,
            "request_file": request_rel,
            "request_sha256": digest((self.output / request_rel).read_bytes()),
            "started_at_utc": utcnow(),
            "valid": False,
        }
        self.attempts.append(attempt)
        self.persist()

        request = urllib.request.Request(ENDPOINT, data=body, method="POST", headers=headers)
        began = time.monotonic()
        status = None
        response_body = b""
        response_headers: dict[str, str] = {}
        error = None
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS, context=SSL_CONTEXT) as response:
                status = response.status
                response_body = response.read()
                response_headers = {"Content-Type": response.headers.get("Content-Type", "")}
        except urllib.error.HTTPError as exc:
            status = exc.code
            response_body = exc.read()
            response_headers = {"Content-Type": exc.headers.get("Content-Type", "")}
            error = f"http_error:{exc.code}"
        except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as exc:
            error = f"transport_error:{type(exc).__name__}:{exc}"
        response_record = {
            "status": status,
            "headers": response_headers,
            "body_raw": response_body.decode("utf-8", errors="replace"),
            "body_sha256": digest(response_body),
            "body_bytes": len(response_body),
            "elapsed_seconds": time.monotonic() - began,
            "finished_at_utc": utcnow(),
            "error": error,
        }
        atomic_json(self.output / response_rel, response_record)
        attempt.update({
            "response_file": response_rel,
            "response_sha256": digest((self.output / response_rel).read_bytes()),
            "http_status": status,
            "response_body_sha256": response_record["body_sha256"],
            "response_bytes": len(response_body),
            "elapsed_seconds": response_record["elapsed_seconds"],
            "error": error,
        })

        lower = response_record["body_raw"].lower()
        if status in (403, 429) or "captcha" in lower or "cf-chl-" in lower:
            self.aborted_reason = f"anti_bot_or_rate_limit:{status}"
            self.persist()
            raise RuntimeError(self.aborted_reason)
        if status == 401 or "authentication required" in lower or "unauthorized" in lower:
            self.aborted_reason = f"authentication_required:{status}"
            self.persist()
            raise RuntimeError(self.aborted_reason)
        if error is not None:
            retryable = status is None or (isinstance(status, int) and 500 <= status < 600)
            attempt["retryable"] = retryable
            self.persist()
            time.sleep(PACE_SECONDS)
            return {"outcome": "retryable" if retryable else "unexpected"}

        expected_total = self.expected[key]["num_found"]
        try:
            payload = json.loads(response_body)
            response = payload["response"]
            docs = response["docs"]
            expected_count = min(ROWS, max(0, expected_total - start))
            if (
                status != 200
                or response["start"] != start
                or response["numFound"] != expected_total
                or len(docs) != expected_count
                or len({doc["pid"] for doc in docs}) != len(docs)
                or not isinstance(payload["facet_counts"]["facet_fields"]["category"], list)
            ):
                raise ValueError("response_window_total_or_facet_invalid")
            prior = {str(doc["pid"]) for doc in self.docs[club].get(key, [])}
            current = {str(doc["pid"]) for doc in docs}
            if prior & current:
                raise ValueError("unexpected_repeated_product_across_windows")
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            self.aborted_reason = f"unexpected_contract_or_pagination:{type(exc).__name__}:{exc}"
            attempt["error"] = self.aborted_reason
            self.persist()
            raise RuntimeError(self.aborted_reason)

        self.new_documents += len(docs)
        if self.new_documents > MAX_NEW_DOCUMENTS:
            self.aborted_reason = "new_document_budget_exceeded"
            self.persist()
            raise RuntimeError(self.aborted_reason)
        self.docs[club].setdefault(key, []).extend(docs)
        window = {
            "source": "remaining_full",
            "start": start,
            "rows": ROWS,
            "returned_documents": len(docs),
            "response_body_sha256": response_record["body_sha256"],
        }
        self.windows[club][key].append(window)
        attempt.update({
            "valid": True,
            "num_found": expected_total,
            "returned_documents": len(docs),
            "facet_nodes": len(payload["facet_counts"]["facet_fields"]["category"]),
        })
        self.persist()
        time.sleep(PACE_SECONDS)
        return {"outcome": "valid"}

    def request_with_retries(self, club: str, key: str, start: int) -> None:
        first_attempt = None
        while True:
            result = self.request(club, key, start, retry_of=first_attempt)
            if result["outcome"] == "valid":
                return
            if result["outcome"] != "retryable":
                self.aborted_reason = "unexpected_http_contract"
                self.persist()
                raise RuntimeError(self.aborted_reason)
            if self.retry_count >= MAX_RETRIES:
                self.aborted_reason = "retry_budget_exhausted"
                self.persist()
                raise RuntimeError(self.aborted_reason)
            if first_attempt is None:
                first_attempt = self.attempts[-1]["attempt_number"]

    def validate_complete(self) -> dict:
        summary: dict[str, dict] = {}
        for club in CLUBS:
            summary[club] = {}
            for key, expected in self.expected.items():
                docs = self.docs[club].get(key, [])
                products = [str(doc["pid"]) for doc in docs]
                if len(docs) != expected["num_found"] or len(set(products)) != len(products):
                    raise RuntimeError(f"root_incomplete:{club}:{key}:{len(docs)}:{expected['num_found']}")
                variants = {
                    str(variant["skuid"])
                    for doc in docs for variant in (doc.get("variants") or [])
                    if variant.get("skuid") is not None
                }
                summary[club][key] = {
                    "expected_num_found": expected["num_found"],
                    "documents": len(docs),
                    "unique_products": len(set(products)),
                    "unique_skus": len(variants),
                    "windows": sorted(self.windows[club][key], key=lambda row: row["start"]),
                }
        return summary

    def run(self) -> None:
        self.output.mkdir(parents=True, exist_ok=False)
        self.persist()
        for item in self.plan:
            self.request_with_retries(item["club"], item["category_key"], item["start"])
        summary = self.validate_complete()
        if self.new_documents != MAX_NEW_DOCUMENTS:
            raise RuntimeError(f"new_document_count_mismatch:{self.new_documents}")
        result = {
            "complete": True,
            "started_at_utc": self.started_at,
            "finished_at_utc": utcnow(),
            "elapsed_seconds": self.elapsed(),
            "post_attempts": len(self.attempts),
            "retries": self.retry_count,
            "remaining_post_budget": MAX_POSTS - len(self.attempts),
            "new_documents": self.new_documents,
            "clubs": summary,
        }
        atomic_json(self.output / "result.json", result)
        self.persist()
        print(json.dumps({
            "complete": True,
            "post_attempts": result["post_attempts"],
            "retries": result["retries"],
            "remaining_post_budget": result["remaining_post_budget"],
            "new_documents": result["new_documents"],
            "elapsed_seconds": result["elapsed_seconds"],
        }, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--alimentos-archive", type=Path, required=True)
    parser.add_argument("--discovery-evidence", type=Path, required=True)
    parser.add_argument("--taxonomy-evidence", type=Path, required=True)
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--execute-authorized-full", action="store_true")
    args = parser.parse_args()
    if args.plan_only == args.execute_authorized_full:
        raise SystemExit("choose exactly one of --plan-only or --execute-authorized-full")
    evidence = json.loads(args.discovery_evidence.read_text())
    taxonomy = json.loads(args.taxonomy_evidence.read_text())
    templates = load_templates(args.alimentos_archive)
    capture = Capture(args.output or Path("unused"), templates, evidence, taxonomy)
    if args.plan_only:
        print(json.dumps({
            "base_requests": len(capture.plan),
            "sps_requests": sum(row["club"] == "6603" for row in capture.plan),
            "florencia_requests": sum(row["club"] == "6602" for row in capture.plan),
            "max_post_attempts": MAX_POSTS,
            "retry_reserve": MAX_RETRIES,
            "partial_probe_windows_reused": False,
        }, sort_keys=True))
        return
    if args.output is None:
        raise SystemExit("--output is required for execution")
    capture.run()


if __name__ == "__main__":
    main()
